Java source directory to hold module-specific Ghidra scripts.
